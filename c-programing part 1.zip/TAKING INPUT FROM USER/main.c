/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
        
        // scanf is used when we take input from user
       
       
        //we used %d for inter otherwise use %f for decimal value and %c for characters
        
        
        
        int a;
        scanf ("%d",&a);
        float b;
        scanf("%f",&b);
        
        char c;
        scanf(" %c", &c);
        
         
    printf("the value of a is %d\n",a);
    
    printf("the value of b is %f\n",b);
    
    printf("the value of c is %c\n", c);
    
    
    
    return 0;
}