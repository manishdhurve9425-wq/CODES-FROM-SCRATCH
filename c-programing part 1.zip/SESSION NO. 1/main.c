#include<stdio.h>

int main(){
       // int a ;variable declaration 

       //  a = 9;variable initialization
         
       //  or 
       int a=6; // also allowed ... called integer const
       
       
         float b = 9.5;//like this...... called real const
         
         
         char c;//either of these two kind of way could be use 
          c='r';//......called character const
         
        printf("the output of this program is %d",a);
        
     
        
        return 0;
}